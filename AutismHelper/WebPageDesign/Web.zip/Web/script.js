function checkAccount() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if(username == '1' && password == '1'){
        window.location = "main.html";
        return false;
    }
    else{
        alert("Incorrect Usernanme or Password!");
    }
}